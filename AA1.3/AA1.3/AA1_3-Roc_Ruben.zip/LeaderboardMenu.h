#pragma once
#include "Menu.h"

class LeaderboardMenu: public Menu
{
public:
	LeaderboardMenu();
};


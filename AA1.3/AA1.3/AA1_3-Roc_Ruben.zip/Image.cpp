#include "Image.h"
#include <iostream>

void Image::Draw()
{
	std::cout << "This is a image \n";
}

#pragma once
#include "Renderer.h"

class Image: public Renderer
{

public:
	void Draw() override;
};


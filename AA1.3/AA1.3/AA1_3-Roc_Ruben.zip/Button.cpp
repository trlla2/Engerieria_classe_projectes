#include "Button.h"
#include <iostream>

void Button::Draw()
{
	std::cout << "This is a button\n";
}

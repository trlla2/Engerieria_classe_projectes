#pragma once
class Renderer
{
public:
	virtual void Draw() = 0;

};


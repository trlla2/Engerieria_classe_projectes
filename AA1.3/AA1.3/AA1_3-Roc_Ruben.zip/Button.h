#pragma once
#include "Renderer.h"

class Button : public Renderer
{
public:
	void Draw() override;

};


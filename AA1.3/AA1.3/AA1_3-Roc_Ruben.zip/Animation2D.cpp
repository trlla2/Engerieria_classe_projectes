#include "Animation2d.h"
#include <iostream>

void Animation2D::Draw()
{
	std::cout << "This is an animation 2D\n";
}

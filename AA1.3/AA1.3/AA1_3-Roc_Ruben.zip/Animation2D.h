#pragma once
#include "Renderer.h"

class Animation2D: public Renderer
{
	void Draw() override;
};


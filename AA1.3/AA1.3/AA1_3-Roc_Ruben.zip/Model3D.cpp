#include "Model3D.h"
#include <iostream>

void Model3D::Draw()
{
	std::cout << "This is an model 3D\n";
}
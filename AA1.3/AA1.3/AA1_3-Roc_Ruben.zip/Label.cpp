#include "Label.h"
#include <iostream>

void Label::Draw()
{
	std::cout << "This is a text(Label)\n";
}

#pragma once
#include "Renderer.h"

class Label : public Renderer
{
public:
	void Draw() override;

};


#pragma once
#include "Renderer.h"

class Model3D :public Renderer
{
public:
	void Draw() override;
};

